# Links
- [GFG UDP CLIENT SERVER](https://www.geeksforgeeks.org/udp-server-client-implementation-c/)
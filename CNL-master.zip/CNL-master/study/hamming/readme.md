# ReferenceLinks
- [Geeks for Geeks - Hamming Code](https://www.geeksforgeeks.org/hamming-code-in-computer-network)
- [Decimal to binary conversino](https://stackoverflow.com/q/22746429) The answer is in the quesion itself
- [Binary to decimal conversino](https://www.geeksforgeeks.org/program-binary-decimal-conversion/) 2nd version